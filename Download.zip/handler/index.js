const fs = require("fs");
const path = require("path");
const { Events } = require("discord.js");

module.exports = async (client) => {
  const SlashsArray = [];
  client.slashCommands ??= new (require("discord.js").Collection)();

  async function loadCommands(dir) {
    const absDir = path.join(__dirname, "..", dir);
    const folders = await fs.promises.readdir(absDir).catch(() => []);
    for (const sub of folders) {
      const subDir = path.join(absDir, sub);
      const stat = await fs.promises.stat(subDir).catch(() => null);
      if (!stat) continue;

      if (stat.isDirectory()) {
        const files = await fs.promises.readdir(subDir).catch(() => []);
        for (const file of files) {
          if (!file.endsWith(".js")) continue;
          const filePath = path.join(subDir, file);

          // evita cache velho em reload
          delete require.cache[require.resolve(filePath)];
          const cmd = require(filePath);

          if (!cmd?.name) continue;
          client.slashCommands.set(cmd.name, cmd);
          SlashsArray.push(cmd);
        }
      } else if (stat.isFile() && sub.endsWith(".js")) {
        const filePath = subDir;
        delete require.cache[require.resolve(filePath)];
        const cmd = require(filePath);
        if (!cmd?.name) continue;
        client.slashCommands.set(cmd.name, cmd);
        SlashsArray.push(cmd);
      }
    }
  }

  await loadCommands("Comandos");

  const READY_EVENT = Events?.ClientReady ?? "ready";

  client.once(READY_EVENT, async () => {
    try {
      // Registra comandos rapidamente. Preferimos global para reduzir chamadas por guilda.
      // Se você quiser apenas por guilda, troque por: guild.commands.set(SlashsArray)
      await client.application.commands.set(SlashsArray);
    } catch (err) {
      console.log("⚠️ Falha ao registrar slash commands:", err?.message || err);
    }
  });
};
