// Simple async mutex per key (single-process). Helps avoid race conditions
// when multiple async flows try to consume the same stock at the same time.

const _queues = new Map();

/**
 * Execute fn under a per-key lock.
 * @param {string} key
 * @param {() => Promise<any>} fn
 */
async function withLock(key, fn) {
  const prev = _queues.get(key) || Promise.resolve();
  let release;
  const next = new Promise((res) => (release = res));

  // chain
  _queues.set(key, prev.then(() => next));
  await prev;

  try {
    return await fn();
  } finally {
    release();
    // cleanup when queue tail reached
    if (_queues.get(key) === next) _queues.delete(key);
  }
}

module.exports = { withLock };
