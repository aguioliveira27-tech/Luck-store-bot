const EfiPay = require("sdk-node-apis-efi");
const axios = require("axios");
const https = require("https");
const fs = require("fs");
const path = require("path");
const { General } = require("../Database/index");

// -------------------- SDK CLIENT (já usado pelo bot) --------------------
async function getEfiClient() {
  const cfg = await General.get("System.Payments.efi");

  if (!cfg?.client_id || !cfg?.client_secret || !cfg?.certificate || !cfg?.pix_key) {
    throw new Error(
      "EFI não configurado: defina client_id, client_secret, pix_key e certificate (caminho do .p12)"
    );
  }

  const options = {
    sandbox: !!cfg.sandbox,
    client_id: cfg.client_id,
    client_secret: cfg.client_secret,
    certificate: cfg.certificate,
    cert_base64: !!cfg.cert_base64,
  };

  return new EfiPay(options);
}

/**
 * Cria Cobrança imediata Pix (COB).
 * Retorna: { txid, copiaecola, status }
 */
async function efiCreatePixCharge({ amountBRL, expireSeconds = 900, orderId, productName, payer }) {
  const efipay = await getEfiClient();
  const cfg = await General.get("System.Payments.efi");

  const body = {
    calendario: { expiracao: expireSeconds },
    valor: { original: Number(amountBRL).toFixed(2) },
    chave: cfg.pix_key,
    solicitacaoPagador: `Pedido ${orderId}${productName ? ` - ${productName}` : ""}`.slice(0, 140),
    infoAdicionais: [
      { nome: "Pedido", valor: String(orderId).slice(0, 50) },
      ...(productName ? [{ nome: "Produto", valor: String(productName).slice(0, 50) }] : []),
    ],
  };

  if (payer?.cpf && payer?.nome) {
    body.devedor = {
      cpf: String(payer.cpf).replace(/\D/g, "").slice(0, 11),
      nome: String(payer.nome).slice(0, 200),
    };
  }

  const res = await efipay.pixCreateImmediateCharge({}, body);

  return {
    txid: res.txid,
    copiaecola: res.pixCopiaECola,
    status: res.status,
  };
}

/**
 * Consulta status da cobrança por TXID.
 * Ex.: ATIVA | CONCLUIDA | REMOVIDA_PELO_USUARIO_RECEBEDOR | REMOVIDA_PELO_PSP
 */
async function efiGetChargeStatus(txid) {
  const efipay = await getEfiClient();
  const res = await efipay.pixDetailCharge({ txid });
  return res?.status;
}

// -------------------- REFUND (API direta com mTLS + OAuth) --------------------
// Base URLs (Efí)
// Produção: https://pix.api.efipay.com.br
// Homologação: https://pix-h.api.efipay.com.br
function _pixBaseUrl(sandbox) {
  return sandbox ? "https://pix-h.api.efipay.com.br" : "https://pix.api.efipay.com.br";
}

function _loadPfxBuffer(cfg) {
  // cfg.certificate pode ser: caminho .p12/.pfx OU base64 (quando cert_base64=true)
  if (cfg?.cert_base64) {
    try {
      return Buffer.from(String(cfg.certificate), "base64");
    } catch (_) {
      throw new Error("Certificado base64 inválido (System.Payments.efi.certificate)");
    }
  }

  const certPath = path.isAbsolute(cfg.certificate)
    ? cfg.certificate
    : path.join(process.cwd(), cfg.certificate);

  if (!fs.existsSync(certPath)) {
    throw new Error(`Certificado .p12 não encontrado: ${certPath}`);
  }
  return fs.readFileSync(certPath);
}

let _tokenCache = {
  access_token: null,
  expires_at: 0, // ms
};

async function _getPixAccessToken() {
  const cfg = await General.get("System.Payments.efi");
  if (!cfg?.client_id || !cfg?.client_secret || !cfg?.certificate) {
    throw new Error("EFI não configurado para OAuth (client_id/client_secret/certificate).");
  }

  const now = Date.now();
  if (_tokenCache.access_token && now < _tokenCache.expires_at - 60_000) {
    return _tokenCache.access_token;
  }

  const pfx = _loadPfxBuffer(cfg);
  const agent = new https.Agent({
    pfx,
    passphrase: cfg?.cert_passphrase ?? "", // a doc geralmente usa vazio
  });

  const auth = Buffer.from(`${cfg.client_id}:${cfg.client_secret}`).toString("base64");
  const url = `${_pixBaseUrl(!!cfg.sandbox)}/oauth/token`;

  const { data } = await axios({
    method: "POST",
    url,
    httpsAgent: agent,
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/json",
    },
    data: { grant_type: "client_credentials" },
    timeout: 25_000,
  });

  if (!data?.access_token) {
    throw new Error("Falha ao obter access_token da Efí.");
  }

  const expiresIn = Number(data.expires_in || 3600);
  _tokenCache = {
    access_token: data.access_token,
    expires_at: now + expiresIn * 1000,
  };

  return data.access_token;
}

async function efiFindE2EIdByTxid(txid, { aroundDate = new Date() } = {}) {
  const cfg = await General.get("System.Payments.efi");
  const token = await _getPixAccessToken();

  const pfx = _loadPfxBuffer(cfg);
  const agent = new https.Agent({
    pfx,
    passphrase: cfg?.cert_passphrase ?? "",
  });

  const base = _pixBaseUrl(!!cfg.sandbox);

  const center = new Date(aroundDate);
  const inicio = new Date(center.getTime() - 7 * 24 * 60 * 60 * 1000); // -7 dias
  const fim = new Date(center.getTime() + 24 * 60 * 60 * 1000); // +1 dia

  const url = `${base}/v2/pix`;

  const { data } = await axios({
    method: "GET",
    url,
    httpsAgent: agent,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    params: {
      inicio: inicio.toISOString(),
      fim: fim.toISOString(),
      txid: String(txid),
    },
    timeout: 25_000,
  });

  const pixArr = Array.isArray(data?.pix) ? data.pix : (Array.isArray(data) ? data : []);
  const found = pixArr.find((p) => p?.txid === txid) || pixArr[0];

  const e2eId = found?.endToEndId || found?.e2eId || found?.endToEndID;
  if (!e2eId) return null;
  return String(e2eId);
}

function _makeRefundId() {
  // id da devolução no endpoint: string curta; mantemos <= 35 chars
  return `rf${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`.slice(0, 35);
}

/**
 * Faz devolução Pix (reembolso) direto para o pagador original.
 * Requer: e2eId (endToEndId) do Pix recebido.
 */
async function efiRefundPix({ e2eId, amountBRL, refundId }) {
  const cfg = await General.get("System.Payments.efi");
  const token = await _getPixAccessToken();

  const pfx = _loadPfxBuffer(cfg);
  const agent = new https.Agent({
    pfx,
    passphrase: cfg?.cert_passphrase ?? "",
  });

  const base = _pixBaseUrl(!!cfg.sandbox);

  const id = refundId || _makeRefundId();
  const url = `${base}/v2/pix/${encodeURIComponent(String(e2eId))}/devolucao/${encodeURIComponent(String(id))}`;

  const { data } = await axios({
    method: "PUT",
    url,
    httpsAgent: agent,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    data: {
      valor: Number(amountBRL).toFixed(2),
    },
    timeout: 25_000,
  });

  return { refundId: id, data };
}

module.exports = {
  getEfiClient,
  efiCreatePixCharge,
  efiGetChargeStatus,
  efiFindE2EIdByTxid,
  efiRefundPix,
};
