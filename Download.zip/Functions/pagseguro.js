const axios = require("axios");
const { General } = require("../Database/index");

/**
 * PagSeguro / PagBank - Integração de Pagamentos (Pix)
 */

async function pagseguroCreatePixCharge({ amountBRL, orderId, description }) {
  const cfg = General.get("System.Payments.pagseguro");
  if (!cfg?.token) throw new Error("PagSeguro não configurado: defina o token no /config");

  const amountCents = Math.round(parseFloat(amountBRL) * 100);

  const body = {
    reference_id: String(orderId),
    description: description ? String(description).slice(0, 200) : `Pedido ${orderId}`,
    amount: {
      value: amountCents,
      currency: "BRL"
    },
    payment_method: {
      type: "PIX",
      installments: 1,
      capture: true,
      soft_descriptor: "Loja Bot",
      pix: {
        expires_in: 1800 // 30 minutos
      }
    },
    notification_urls: []
  };

  const res = await axios.post("https://api.pagseguro.com/orders", body, {
    headers: {
      Authorization: `Bearer ${cfg.token}`,
      "Content-Type": "application/json"
    },
    timeout: 15000
  });

  const pixCharge = res.data?.charges?.[0]?.payment_response?.pix;

  return {
    orderId: res.data?.id,
    copiaecola: pixCharge?.qr_codes?.[0]?.text || null,
    status: res.data?.charges?.[0]?.status || "WAITING"
  };
}

async function pagseguroGetStatus(chargeId) {
  const cfg = General.get("System.Payments.pagseguro");
  if (!cfg?.token) throw new Error("PagSeguro não configurado");

  const res = await axios.get(`https://api.pagseguro.com/charges/${chargeId}`, {
    headers: { Authorization: `Bearer ${cfg.token}` },
    timeout: 15000
  });

  const s = res.data?.status;
  if (s === "PAID") return "CONCLUIDA";
  return s || "ATIVA";
}

module.exports = { pagseguroCreatePixCharge, pagseguroGetStatus };
