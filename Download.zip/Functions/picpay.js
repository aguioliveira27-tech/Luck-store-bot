const axios = require("axios");
const { General } = require("../Database/index");

/**
 * PicPay - Integração de Pagamentos
 */

async function picpayCreateCharge({ amountBRL, orderId, productName, buyerName, buyerEmail }) {
  const cfg = General.get("System.Payments.picpay");
  if (!cfg?.token) throw new Error("PicPay não configurado: defina o token no /config");

  const callbackUrl = `https://picpay.com/`; // Configurar webhook se necessário

  const body = {
    referenceId: String(orderId),
    callbackUrl,
    returnUrl: callbackUrl,
    value: parseFloat(Number(amountBRL).toFixed(2)),
    additionalInfo: productName ? [{ label: "Produto", value: String(productName).slice(0, 100) }] : [],
    buyer: {
      firstName: buyerName ? String(buyerName).split(" ")[0] : "Cliente",
      lastName: buyerName ? String(buyerName).split(" ").slice(1).join(" ") || "." : ".",
      email: buyerEmail || "cliente@email.com",
    }
  };

  const res = await axios.post("https://appws.picpay.com/ecommerce/public/v2/payments", body, {
    headers: {
      "Content-Type": "application/json",
      "x-picpay-token": cfg.token
    },
    timeout: 15000
  });

  return {
    referenceId: res.data.referenceId,
    paymentUrl: res.data.paymentUrl,
    qrcode: res.data.qrcode?.content || null,
    status: res.data.status
  };
}

async function picpayGetStatus(referenceId) {
  const cfg = General.get("System.Payments.picpay");
  if (!cfg?.token) throw new Error("PicPay não configurado");

  const res = await axios.get(`https://appws.picpay.com/ecommerce/public/v2/payments/${referenceId}/status`, {
    headers: { "x-picpay-token": cfg.token },
    timeout: 15000
  });

  return res.data?.authorizationId ? "paid" : res.data?.status || "pending";
}

module.exports = { picpayCreateCharge, picpayGetStatus };
