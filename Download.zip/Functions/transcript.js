const { AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

async function generateTranscript(channel, ticketData) {
    try {
        let messages = [];
        let lastId;

        // Buscar todas as mensagens do canal (limite de 100 por vez)
        while (true) {
            const options = { limit: 100 };
            if (lastId) options.before = lastId;

            const fetched = await channel.messages.fetch(options);
            if (fetched.size === 0) break;
            
            messages.push(...fetched.values());
            lastId = fetched.last().id;

            if (fetched.size < 100) break;
        }

        messages.reverse(); // Colocar em ordem cronológica

        let html = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Transcript - Ticket ${ticketData.id_ticket}</title>
    <style>
        body { background-color: #36393f; color: #dcddde; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; }
        .header { border-bottom: 1px solid #4f545c; padding-bottom: 10px; margin-bottom: 20px; }
        .message { display: flex; margin-bottom: 15px; }
        .avatar { width: 40px; height: 40px; border-radius: 50%; margin-right: 15px; }
        .content { flex: 1; }
        .author { font-weight: bold; color: #fff; margin-right: 5px; }
        .timestamp { font-size: 0.75rem; color: #72767d; }
        .text { margin-top: 5px; line-height: 1.4; white-space: pre-wrap; word-break: break-word; }
        .attachment { margin-top: 10px; max-width: 100%; border-radius: 4px; }
        .embed { margin-top: 10px; padding: 10px; border-left: 4px solid #202225; background: #2f3136; border-radius: 4px; }
        .embed-title { color: #fff; font-weight: bold; margin-bottom: 5px; }
        .embed-description { font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Transcript do Ticket: ${ticketData.id_ticket}</h1>
            <p>${channel.name}</p>
            <p>Data de Abertura: ${new Date(ticketData.info.opened_date).toLocaleString('pt-BR')}</p>
        </div>
        <div class="messages">
        `;

        for (const msg of messages) {
            const timestamp = msg.createdAt.toLocaleString('pt-BR');
            const avatarUrl = msg.author.displayAvatarURL({ extension: 'png', size: 128 });
            
            html += `
            <div class="message">
                <img src="${avatarUrl}" class="avatar" alt="Avatar">
                <div class="content">
                    <div>
                        <span class="author">${msg.author.tag}</span>
                        <span class="timestamp">${timestamp}</span>
                    </div>
                    <div class="text">${msg.content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
            `;

            // Anexos
            if (msg.attachments.size > 0) {
                msg.attachments.forEach(att => {
                    if (att.contentType && att.contentType.startsWith('image/')) {
                        html += `<img src="${att.url}" class="attachment" alt="Imagem">`;
                    } else {
                        html += `<div class="text"><a href="${att.url}" style="color: #00aff4;">Anexo: ${att.name}</a></div>`;
                    }
                });
            }

            // Embeds (simplificado)
            if (msg.embeds.length > 0) {
                msg.embeds.forEach(embed => {
                    html += `<div class="embed">`;
                    if (embed.title) html += `<div class="embed-title">${embed.title}</div>`;
                    if (embed.description) html += `<div class="embed-description">${embed.description}</div>`;
                    html += `</div>`;
                });
            }

            html += `
                </div>
            </div>
            `;
        }

        html += `
        </div>
    </div>
</body>
</html>
        `;

        const fileName = `transcript-${ticketData.id_ticket}.html`;
        const filePath = path.join(__dirname, '..', fileName);
        fs.writeFileSync(filePath, html);

        const attachment = new AttachmentBuilder(filePath, { name: fileName });
        
        return { attachment, filePath };
    } catch (error) {
        console.error('Erro ao gerar transcript:', error);
        return null;
    }
}

module.exports = { generateTranscript };
