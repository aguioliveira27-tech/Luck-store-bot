const axios = require("axios");
const { General } = require("../Database/index");

/**
 * PayPal - Integração de Pagamentos
 */

async function paypalGetAccessToken() {
  const cfg = General.get("System.Payments.paypal");
  if (!cfg?.client_id || !cfg?.client_secret) throw new Error("PayPal não configurado");

  const baseUrl = cfg.sandbox
    ? "https://api-m.sandbox.paypal.com"
    : "https://api-m.paypal.com";

  const res = await axios.post(`${baseUrl}/v1/oauth2/token`, "grant_type=client_credentials", {
    auth: { username: cfg.client_id, password: cfg.client_secret },
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    timeout: 15000
  });

  return { token: res.data.access_token, baseUrl };
}

async function paypalCreateOrder({ amountBRL, orderId, description }) {
  const cfg = General.get("System.Payments.paypal");
  if (!cfg?.client_id) throw new Error("PayPal não configurado: defina as credenciais no /config");

  const { token, baseUrl } = await paypalGetAccessToken();

  const body = {
    intent: "CAPTURE",
    purchase_units: [{
      reference_id: String(orderId),
      description: description ? String(description).slice(0, 127) : `Pedido ${orderId}`,
      amount: {
        currency_code: "BRL",
        value: Number(amountBRL).toFixed(2)
      }
    }],
    payment_source: {
      paypal: {
        experience_context: {
          payment_method_preference: "IMMEDIATE_PAYMENT_REQUIRED",
          landing_page: "LOGIN",
          user_action: "PAY_NOW",
          return_url: "https://example.com/return",
          cancel_url: "https://example.com/cancel"
        }
      }
    }
  };

  const res = await axios.post(`${baseUrl}/v2/checkout/orders`, body, {
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    timeout: 15000
  });

  const approveLink = res.data.links?.find(l => l.rel === "payer-action")?.href || null;

  return {
    id: res.data.id,
    approveUrl: approveLink,
    status: res.data.status
  };
}

async function paypalGetOrderStatus(paypalOrderId) {
  const { token, baseUrl } = await paypalGetAccessToken();

  const res = await axios.get(`${baseUrl}/v2/checkout/orders/${paypalOrderId}`, {
    headers: { Authorization: `Bearer ${token}` },
    timeout: 15000
  });

  const s = res.data?.status;
  if (s === "COMPLETED") return "CONCLUIDA";
  if (s === "APPROVED") return "ATIVA";
  return s || "ATIVA";
}

module.exports = { paypalCreateOrder, paypalGetOrderStatus };
