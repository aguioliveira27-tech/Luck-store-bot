const { EmbedBuilder, ButtonBuilder, ActionRowBuilder, MessageFlagsBitField, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require("discord.js");
const { General, Produtos, Carrinhos, Tickets } = require("../Database/index");
const { timing } = require("../Functions/utils");
const startTime = Date.now();

// ─────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────
function statusDot(enabled) { return enabled ? "🟢" : "🔴"; }
function maskSecret(str, show = 8) {
  if (!str || str.length < show) return str || "Não definido";
  return "•".repeat(Math.max(str.length - show, 4)) + str.slice(-show);
}

// ─────────────────────────────────────────────
//  MAIN PANEL  (/config)
// ─────────────────────────────────────────────
async function Main(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  const ping = client.ws.ping;
  const uptime = `<t:${Math.ceil(startTime / 1000)}:R>`;

  const embed = new EmbedBuilder()
    .setAuthor({ name: `⚙️  Painel de Configuração`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
    .setDescription(
      `${timing()}, **${interaction.user.username}** 👋\n\n` +
      `Bem-vindo ao painel central do bot. Navegue pelas categorias abaixo para configurar cada aspecto da sua loja.\n\n` +
      `> 📡 **Ping:** \`${ping} ms\`  •  🕐 **Uptime:** ${uptime}`
    )
    .setColor(color)
    .setFooter({ text: `${interaction.guild.name}  •  ${client.user.username}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
    .setTimestamp();

  await interaction.update({
    content: "",
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("GerenciarLoja").setLabel("Loja").setEmoji("1319043599521812480").setStyle(2),
        new ButtonBuilder().setCustomId("GerenciarTickets").setLabel("Atendimentos").setEmoji("1319043579179696271").setStyle(2),
        new ButtonBuilder().setCustomId("PersonalizaAPP").setLabel("Personalização").setEmoji("1319043534547976242").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("GerenciarDefinicoes").setLabel("Configurações").setEmoji("1319043594941759579").setStyle(2),
        new ButtonBuilder().setCustomId("autoReactSetup").setLabel("Auto-React").setEmoji("1319043602604752997").setStyle(2),
        new ButtonBuilder().setCustomId("rendimentosOptions").setLabel("Rentabilidade").setEmoji("1319004166424891515").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  CONFIGURAÇÕES
// ─────────────────────────────────────────────
async function Configurações(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "⚙️  Configurações", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription("Selecione o que deseja configurar:")
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("GerenciarCargos").setLabel("Gerenciar Cargos").setEmoji("1276927582419554316").setStyle(2),
        new ButtonBuilder().setCustomId("GerenciarCanais").setLabel("Gerenciar Logs").setEmoji("1276927585544044598").setStyle(2),
        new ButtonBuilder().setCustomId("MetodosPagamento").setLabel("Formas de Pagamento").setEmoji("1273049581667745864").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltar1").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  CARGOS
// ─────────────────────────────────────────────
async function RoleSetup(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  const r = (key) => {
    const id = General.get(key);
    return id ? `<@&${id}>` : "`Não definido`";
  };

  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "👥  Gerenciar Cargos", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(
          `Configure os cargos da sua loja abaixo:\n\n` +
          `👑  **Administrador:** ${r("Config.Roles.admin")}\n` +
          `🛡️  **Suporte:** ${r("Config.Roles.staff")}\n` +
          `🛒  **Cliente:** ${r("Config.Roles.costumer")}\n` +
          `👤  **Membro:** ${r("Config.Roles.member")}`
        )
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("changecargoadmin").setLabel("👑  Admin").setStyle(2),
        new ButtonBuilder().setCustomId("changecargostaff").setLabel("🛡️  Suporte").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("changecargoCostumer").setLabel("Cargo Cliente").setEmoji("1276564807335809156").setStyle(2),
        new ButtonBuilder().setCustomId("changecargomembro").setLabel("👤  Membro").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltar2").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  CANAIS DE LOG
// ─────────────────────────────────────────────
async function ChannelSetup(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  const c = (key) => {
    const id = General.get(key);
    return id ? `<#${id}>` : "`Não definido`";
  };

  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "📋  Logs & Canais", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(
          `Configure os canais de log da loja:\n\n` +
          `🎫  **Tickets:** ${c("Config.logs.ticketChannel")}\n` +
          `🖥️  **Sistema:** ${c("Config.logs.Sistema")}\n` +
          `🚪  **Entradas/Saídas:** ${c("Config.logs.trafego")}\n` +
          `📦  **Vendas (Admin):** ${c("Config.logs.VendasADM")}\n` +
          `📢  **Vendas (Público):** ${c("Config.logs.VendasPUB")}\n` +
          `⭐  **Feedbacks:** ${c("Config.logs.feedbacks")}`
        )
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("DefinirlogsTickets").setLabel("Logs de Ticket").setEmoji("1267032211455082508").setStyle(2),
        new ButtonBuilder().setCustomId("DefinirlogsSistema").setLabel("Logs Sistema").setEmoji("1267032211455082508").setStyle(2),
        new ButtonBuilder().setCustomId("DefinirlogsTrafego").setLabel("Entradas e Saídas").setEmoji("1267032211455082508").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("DefinirlogsVendaADM").setLabel("Logs de Vendas").setEmoji("1267032211455082508").setStyle(2),
        new ButtonBuilder().setCustomId("DefinirlogsVendaPublic").setLabel("Logs Entregas").setEmoji("1267032211455082508").setStyle(2),
        new ButtonBuilder().setCustomId("DefinirlogsVouch").setLabel("Canal Feedbacks").setEmoji("1267032211455082508").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltar2").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  PAGAMENTOS
// ─────────────────────────────────────────────
async function PaymentSetup(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  const p = (key) => General.get(`System.Payments.${key}.status`);

  const pixMenu = new StringSelectMenuBuilder()
    .setCustomId("selectMethodPix")
    .setPlaceholder("🏦  [PIX] Selecionar gateway ativo")
    .setMaxValues(1)
    .addOptions(
      new StringSelectMenuOptionBuilder().setLabel("Efí Bank").setDescription("PIX automático com certificado .p12").setEmoji(statusDot(p("efi"))).setValue("onoffEFI"),
      new StringSelectMenuOptionBuilder().setLabel("MercadoPago").setDescription("PIX via Mercado Pago").setEmoji(statusDot(p("mercadopago"))).setValue("onoffMP"),
      new StringSelectMenuOptionBuilder().setLabel("Asaas").setDescription("PIX via Asaas/PagBank").setEmoji(statusDot(p("asaas"))).setValue("onoffAsaas"),
      new StringSelectMenuOptionBuilder().setLabel("PagSeguro").setDescription("PIX via PagSeguro").setEmoji(statusDot(p("pagseguro"))).setValue("onoffPagseguro"),
      new StringSelectMenuOptionBuilder().setLabel("Semi-Automático").setDescription("Chave Pix manual (sem API)").setEmoji(statusDot(p("semiauto"))).setValue("onoffSemiauto")
    );

  const cardMenu = new StringSelectMenuBuilder()
    .setCustomId("selectMethodCard")
    .setPlaceholder("💳  [CARTÃO/LINK] Selecionar gateway ativo")
    .setMaxValues(1)
    .addOptions(
      new StringSelectMenuOptionBuilder().setLabel("Stripe").setDescription("Cartão via Stripe (checkout session)").setEmoji(statusDot(p("stripe"))).setValue("onoffStripe"),
      new StringSelectMenuOptionBuilder().setLabel("PicPay").setDescription("Pagamento via link PicPay").setEmoji(statusDot(p("picpay"))).setValue("onoffPicpay"),
      new StringSelectMenuOptionBuilder().setLabel("PayPal").setDescription("Pagamento via PayPal (link)").setEmoji(statusDot(p("paypal"))).setValue("onoffPaypal")
    );

  const embed = new EmbedBuilder()
    .setAuthor({ name: "💳  Formas de Pagamento", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
    .setDescription(
      `Configure e ative os gateways de pagamento da sua loja.\n\n` +
      `O emoji ${statusDot(true)} indica o gateway **ativo** que processa os pedidos.\n` +
      `O emoji ${statusDot(false)} indica gateway **inativo**.\n\n` +
      `**Gateways PIX:**\n` +
      `${statusDot(p("efi"))} Efí Bank  •  ${statusDot(p("mercadopago"))} MercadoPago  •  ${statusDot(p("asaas"))} Asaas  •  ${statusDot(p("pagseguro"))} PagSeguro  •  ${statusDot(p("semiauto"))} Semi-Auto\n\n` +
      `**Gateways Cartão/Link:**\n` +
      `${statusDot(p("stripe"))} Stripe  •  ${statusDot(p("picpay"))} PicPay  •  ${statusDot(p("paypal"))} PayPal`
    )
    .setColor(color)
    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
    .setTimestamp();

  await interaction.update({
    content: "",
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(pixMenu),
      new ActionRowBuilder().addComponents(cardMenu),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("MPSetup").setEmoji("1273106836790444147").setStyle(2),
        new ButtonBuilder().setCustomId("EFISetup").setEmoji("1296065449737457734").setStyle(2),
        new ButtonBuilder().setCustomId("AsaasSetup").setLabel("Asaas").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("StripePaySetup").setEmoji("1356173479376064512").setStyle(2),
        new ButtonBuilder().setCustomId("PicpaySetup").setLabel("PicPay").setStyle(2),
        new ButtonBuilder().setCustomId("PaypalSetup").setLabel("PayPal").setStyle(2),
        new ButtonBuilder().setCustomId("PagseguroSetup").setLabel("PagSeguro").setStyle(2),
        new ButtonBuilder().setCustomId("SemiAutoPaySetup").setLabel("Semi-Automático").setEmoji("1251441500407992351").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltar2").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  AUTO-REACT SETUP
// ─────────────────────────────────────────────
async function AutoReactSetup(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  const cfg = General.get("System.AutoReact") || {};
  const enabled = !!cfg.enabled;
  const channels = cfg.channels || [];
  const emoji = cfg.emoji || "Não definido";

  const channelList = channels.length > 0
    ? channels.map(id => `<#${id}>`).join("  •  ")
    : "`Nenhum canal configurado`";

  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "⭐  Auto-React", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(
          `O bot reagirá automaticamente às mensagens nos canais configurados.\n\n` +
          `${statusDot(enabled)} **Status:** ${enabled ? "Ativado" : "Desativado"}\n` +
          `😀  **Emoji:** \`${emoji}\`\n` +
          `📌  **Canais:** ${channelList}`
        )
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("autoReactToggle")
          .setLabel(enabled ? "Desativar" : "Ativar").setEmoji(enabled ? "1251441411266711573" : "1251441497346281482")
          .setStyle(enabled ? 4 : 3),
        new ButtonBuilder().setCustomId("autoReactSetEmoji").setLabel("Definir Emoji").setEmoji("1319043602604752997").setStyle(2),
        new ButtonBuilder().setCustomId("autoReactSetChannels").setLabel("Definir Canais").setEmoji("1267032211455082508").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltar1").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  CUSTOMIZAR
// ─────────────────────────────────────────────
async function Customizar(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "🎨  Personalização", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription("Personalize a aparência do seu bot:")
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("setnameBot").setLabel("Nome").setEmoji("1264379809845477406").setStyle(2),
        new ButtonBuilder().setCustomId("setdescBot").setLabel("Descrição").setEmoji("1264379809845477406").setStyle(2),
        new ButtonBuilder().setCustomId("setatividadeBot").setLabel("Status").setEmoji("1264379809845477406").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("setlogoBot").setLabel("Imagem de Perfil").setEmoji("1268061007436320828").setStyle(2),
        new ButtonBuilder().setCustomId("setbannerBot").setLabel("Banner no Perfil").setEmoji("1268061007436320828").setStyle(2),
        new ButtonBuilder().setCustomId("setcolormainBot").setLabel("Cor Principal").setEmoji("1263226754739343531").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltar1").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  LOJA SETUP
// ─────────────────────────────────────────────
async function LojaSetup(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "🛒  Gerenciar Loja", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription("Gerencie produtos e personalizações da loja:")
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("marcaLoja").setLabel("Personalizações").setEmoji("1263226754739343531").setStyle(2),
        new ButtonBuilder().setCustomId("manageProduct").setLabel("Produtos").setEmoji("1276564808723861667").setStyle(1)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("createProduct").setLabel("Criar Produto").setEmoji("1251441497346281482").setStyle(3),
        new ButtonBuilder().setCustomId("deleteProduct").setLabel("Excluir Produto").setEmoji("1251441411266711573").setStyle(4),
        new ButtonBuilder().setCustomId("rendimentosOptions").setLabel("Rentabilidade").setEmoji("1319004166424891515").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltar1").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  TICKET SETUP
// ─────────────────────────────────────────────
async function TicketSetup(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  let embed = new EmbedBuilder()
    .setAuthor({ name: "🎫  Configurar Tickets", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
    .setColor(color)
    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
    .setTimestamp();

  const title = Tickets.get("Panel.title");
  const description = Tickets.get("Panel.description");
  const funcoes = Tickets.get("Panel.funcoes") || [];

  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  funcoes.forEach(f => {
    embed.addFields({ name: `**${f.title}**`, value: `Descrição: \`${f.desc || "N/A"}\`` });
  });

  await interaction.update({
    content: "",
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("createFuncTicket").setLabel("Criar Função").setEmoji("1251441497346281482").setStyle(3),
        new ButtonBuilder().setCustomId("deleteFuncTicket").setLabel("Deletar Função").setEmoji("1251441845242695710").setStyle(4)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("customTicketPanel").setLabel("Customizar Embed").setEmoji("1273127418386976788").setStyle(2),
        new ButtonBuilder().setCustomId("manageFuncTicket").setLabel("Gerenciar Funções").setEmoji("1276564808723861667").setStyle(1)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("sendTicketPanel").setLabel("Enviar Painel").setEmoji("1263220780615991306").setStyle(2),
        new ButtonBuilder().setCustomId("updateTicketPanel").setLabel("Atualizar Painel").setEmoji("1262641711834861599").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltar1").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  MARCA SETUP
// ─────────────────────────────────────────────
async function MarcaSetup(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  const fp = General.get("System.Marca.feedbackPanel") || {};
  const fpEnabled = !!fp.enabled;
  const autoReactEnabled = !!(General.get("System.AutoReact.enabled"));

  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "🏷️  Marca & Personalizações", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(
          `Personalize como sua marca aparece para os clientes:\n\n` +
          `${statusDot(fpEnabled)} **Painel de Feedbacks:** ${fpEnabled ? "Ativo" : "Inativo"}\n` +
          `${statusDot(autoReactEnabled)} **Auto-React:** ${autoReactEnabled ? "Ativo" : "Inativo"}`
        )
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("QRcodeSetupLogo").setLabel("Logo QrCode").setEmoji("1319043538947801179").setStyle(2),
        new ButtonBuilder().setCustomId("QRcodeSetupColor").setLabel("Cor QrCode").setEmoji("1261436901941055560").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("msgbuySetup").setLabel("Mensagem Pós Venda").setEmoji("1319131699321503834").setStyle(2),
        new ButtonBuilder().setCustomId("emojiFeedback").setLabel("Auto-React Feedback").setEmoji("1319043602604752997").setStyle(2)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("feedbackPanelSetup").setLabel("Painel no Canal Feedbacks").setEmoji("1319043599521812480").setStyle(2),
        new ButtonBuilder()
          .setCustomId("feedbackPanelToggle")
          .setLabel(fpEnabled ? "Desativar Painel" : "Ativar Painel").setEmoji(fpEnabled ? "1251441411266711573" : "1251441497346281482")
          .setStyle(fpEnabled ? 4 : 3)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltarLojaSetup").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  RENDIMENTOS
// ─────────────────────────────────────────────
async function rendimentosOptions(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  const dataOrderArray = Carrinhos.all();
  let totalDiario = 0, totalSemanal = 0, totalQuinzenal = 0, totalMensal = 0, total = 0, totalOrders = 0;
  const agora = new Date();
  const inicioDia = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate(), 0, 1, 0);
  const inicioSemana = new Date(agora);
  inicioSemana.setDate(agora.getDate() - agora.getDay() + 1);
  inicioSemana.setHours(0, 1, 0, 0);
  const inicioQuinzena = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() >= 16 ? 16 : 1, 0, 1, 0);
  const inicioMes = new Date(agora.getFullYear(), agora.getMonth(), 1, 0, 1, 0);

  if (Array.isArray(dataOrderArray)) {
    for (const orderEntry of dataOrderArray) {
      const userOrders = orderEntry.data;
      for (const carrinhoId in userOrders) {
        const data = userOrders[carrinhoId];
        if (data.status !== "approved") continue;
        const pagamento = data.payment_info?.[0];
        if (!pagamento) continue;
        const valor = parseFloat(pagamento.total) || 0;
        const dataApproved = new Date(pagamento.approvation_date);
        if (dataApproved >= inicioDia) totalDiario += valor;
        if (dataApproved >= inicioSemana) totalSemanal += valor;
        if (dataApproved >= inicioQuinzena) totalQuinzenal += valor;
        if (dataApproved >= inicioMes) totalMensal += valor;
        total += valor;
        totalOrders++;
      }
    }
  }

  const fmt = (v) => `R$ ${v.toFixed(2)}`;

  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "📊  Relatório de Rendimentos", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(
          `**📅  Hoje:** \`${fmt(totalDiario)}\`\n` +
          `**📆  Esta semana:** \`${fmt(totalSemanal)}\`\n` +
          `**🗓️  Quinzena:** \`${fmt(totalQuinzenal)}\`\n` +
          `**📅  Este mês:** \`${fmt(totalMensal)}\`\n\n` +
          `**💰  Total acumulado:** \`${fmt(total)}\`\n` +
          `**📦  Pedidos aprovados:** \`${totalOrders}\``
        )
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltarLojaSetup").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  DETAIL PAYMENTS
// ─────────────────────────────────────────────
async function detailPayments(option, client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  const back = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("voltarpaysetup").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
  );

  const cases = {
    1: async () => {
      const Config = General.get("System.Payments.mercadopago") || {};
      return {
        title: "MercadoPago",
        desc: `**Token:** ${Config.token ? `||\`${maskSecret(Config.token)}\`||` : "`Não definido`"}`,
        info: "Checkout transparente do Mercado Pago. Pagamentos via Pix são processados automaticamente.",
        btn: new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("setMPtoken").setLabel("🔑  Access Token").setStyle(2)
        )
      };
    },
    2: async () => {
      const Config = General.get("System.Payments.semiauto") || {};
      return {
        title: "Semi-Automático",
        desc: `**Chave Pix:** ${Config.key ? `||\`${maskSecret(Config.key)}\`||` : "`Não definido`"}`,
        info: "Gera QR Code Pix personalizado. A aprovação do pedido deve ser feita manualmente pelo admin.",
        btn: new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("configpix").setLabel("🔑  Chave Pix").setStyle(2)
        )
      };
    },
    3: async () => {
      const Config = General.get("System.Payments.efi") || {};
      return {
        title: "Efí Bank (PIX)",
        desc: `**Sandbox:** \`${Config.sandbox ? "true" : "false"}\`\n**Client ID:** ${Config.client_id ? `||\`${maskSecret(Config.client_id)}\`||` : "`Não definido`"}\n**Client Secret:** ${Config.client_secret ? `||\`${maskSecret(Config.client_secret)}\`||` : "`Não definido`"}\n**Chave Pix:** ${Config.pix_key ? `||\`${maskSecret(Config.pix_key)}\`||` : "`Não definido`"}\n**Certificado:** \`${Config.certificate || "Não definido"}\``,
        info: "Integração PIX com API Efí Bank. Requer certificado .p12.",
        btn: new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("setEFIConfig").setLabel("🔑  Credenciais").setStyle(2),
          new ButtonBuilder().setCustomId("setEFICertPath").setLabel("📄  Certificado .p12").setStyle(2)
        )
      };
    },
    4: async () => {
      const Config = General.get("System.Payments.stripe") || {};
      return {
        title: "Stripe",
        desc: `**Secret Key:** ${Config.token ? `||\`${maskSecret(Config.token)}\`||` : "`Não definido`"}\n**Webhook Secret:** ${Config.webhook_secret ? `||\`${maskSecret(Config.webhook_secret)}\`||` : "`Não definido`"}`,
        info: "Pagamentos com cartão via Stripe Checkout Sessions. O cliente é redirecionado para a página de pagamento da Stripe.",
        btn: new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("setStripetoken").setLabel("🔑  Secret Key").setStyle(2),
          new ButtonBuilder().setCustomId("setStripeWebhook").setLabel("🔗  Webhook Secret").setStyle(2)
        )
      };
    },
    5: async () => {
      const Config = General.get("System.Payments.picpay") || {};
      return {
        title: "PicPay",
        desc: `**Token:** ${Config.token ? `||\`${maskSecret(Config.token)}\`||` : "`Não definido`"}`,
        info: "Pagamento via link PicPay. O cliente acessa o link para finalizar o pagamento.",
        btn: new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("setPicpayToken").setLabel("🔑  Token PicPay").setStyle(2)
        )
      };
    },
    6: async () => {
      const Config = General.get("System.Payments.asaas") || {};
      return {
        title: "Asaas",
        desc: `**Sandbox:** \`${Config.sandbox ? "true" : "false"}\`\n**Token:** ${Config.token ? `||\`${maskSecret(Config.token)}\`||` : "`Não definido`"}`,
        info: "PIX automático via Asaas. Aprovação instantânea.",
        btn: new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("setAsaasToken").setLabel("🔑  API Key").setStyle(2)
        )
      };
    },
    7: async () => {
      const Config = General.get("System.Payments.pagseguro") || {};
      return {
        title: "PagSeguro",
        desc: `**Token:** ${Config.token ? `||\`${maskSecret(Config.token)}\`||` : "`Não definido`"}`,
        info: "PIX via PagSeguro/PagBank. Token gerado no painel PagBank.",
        btn: new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("setPagseguroToken").setLabel("🔑  Token").setStyle(2)
        )
      };
    },
    8: async () => {
      const Config = General.get("System.Payments.paypal") || {};
      return {
        title: "PayPal",
        desc: `**Sandbox:** \`${Config.sandbox ? "true" : "false"}\`\n**Client ID:** ${Config.client_id ? `||\`${maskSecret(Config.client_id)}\`||` : "`Não definido`"}\n**Client Secret:** ${Config.client_secret ? `||\`${maskSecret(Config.client_secret)}\`||` : "`Não definido`"}`,
        info: "Pagamento via link PayPal. O cliente é redirecionado para o PayPal.",
        btn: new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("setPaypalCreds").setLabel("🔑  Credenciais").setStyle(2)
        )
      };
    }
  };

  if (!cases[option]) return;
  const data = await cases[option]();

  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: `💳  ${data.title}`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(`${data.desc}\n\n> ${data.info}`)
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [data.btn, back],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

// ─────────────────────────────────────────────
//  PLANS SETUP
// ─────────────────────────────────────────────
async function plansSetup(client, interaction) {
  const color = General.get("System.Colors.main") || "#a833ff";
  await interaction.update({
    content: "",
    embeds: [
      new EmbedBuilder()
        .setAuthor({ name: "📋  Assinaturas", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
        .setDescription("Gerencie os planos de assinatura da loja:")
        .setColor(color)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
        .setTimestamp()
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("createPlans").setLabel("Criar Assinatura").setEmoji("1251441497346281482").setStyle(3),
        new ButtonBuilder().setCustomId("managePlans").setLabel("Assinaturas").setEmoji("1276564808723861667").setStyle(1),
        new ButtonBuilder().setCustomId("deletePlans").setLabel("Excluir Assinaturas").setEmoji("1251441411266711573").setStyle(4)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("voltarLojaSetup").setLabel("Voltar").setEmoji("1251441490576805979").setStyle(2)
      )
    ],
    flags: MessageFlagsBitField.Flags.Ephemeral
  });
}

module.exports = {
  Main,
  Configurações,
  RoleSetup,
  ChannelSetup,
  PaymentSetup,
  AutoReactSetup,
  Customizar,
  LojaSetup,
  TicketSetup,
  MarcaSetup,
  rendimentosOptions,
  detailPayments,
  plansSetup
};
