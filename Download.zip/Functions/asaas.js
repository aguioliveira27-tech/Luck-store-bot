const axios = require("axios");
const { General } = require("../Database/index");

/**
 * Asaas - Integração de Pagamentos (Pix)
 */

function getAsaasBaseUrl() {
  const cfg = General.get("System.Payments.asaas");
  return cfg?.sandbox
    ? "https://sandbox.asaas.com/api/v3"
    : "https://api.asaas.com/api/v3";
}

async function asaasCreateCustomer({ name, email, cpfCnpj }) {
  const cfg = General.get("System.Payments.asaas");
  if (!cfg?.token) throw new Error("Asaas não configurado");

  const body = { name, email };
  if (cpfCnpj) body.cpfCnpj = String(cpfCnpj).replace(/\D/g, "");

  const res = await axios.post(`${getAsaasBaseUrl()}/customers`, body, {
    headers: { access_token: cfg.token, "Content-Type": "application/json" },
    timeout: 15000
  });

  return res.data;
}

async function asaasCreatePixCharge({ amountBRL, orderId, customerId, description }) {
  const cfg = General.get("System.Payments.asaas");
  if (!cfg?.token) throw new Error("Asaas não configurado: defina o token no /config");

  const dueDate = new Date();
  dueDate.setMinutes(dueDate.getMinutes() + 30);

  const body = {
    customer: customerId,
    billingType: "PIX",
    value: parseFloat(Number(amountBRL).toFixed(2)),
    dueDate: dueDate.toISOString().split("T")[0],
    description: description ? String(description).slice(0, 255) : `Pedido ${orderId}`,
    externalReference: String(orderId)
  };

  const res = await axios.post(`${getAsaasBaseUrl()}/payments`, body, {
    headers: { access_token: cfg.token, "Content-Type": "application/json" },
    timeout: 15000
  });

  const paymentId = res.data.id;

  // Busca QR Code Pix
  const pixRes = await axios.get(`${getAsaasBaseUrl()}/payments/${paymentId}/pixQrCode`, {
    headers: { access_token: cfg.token },
    timeout: 15000
  });

  return {
    paymentId,
    copiaecola: pixRes.data?.payload || null,
    encodedImage: pixRes.data?.encodedImage || null,
    status: res.data.status
  };
}

async function asaasGetStatus(paymentId) {
  const cfg = General.get("System.Payments.asaas");
  if (!cfg?.token) throw new Error("Asaas não configurado");

  const res = await axios.get(`${getAsaasBaseUrl()}/payments/${paymentId}`, {
    headers: { access_token: cfg.token },
    timeout: 15000
  });

  const s = res.data?.status;
  if (s === "RECEIVED" || s === "CONFIRMED") return "CONCLUIDA";
  if (s === "PENDING") return "ATIVA";
  return s || "ATIVA";
}

module.exports = { asaasCreateCustomer, asaasCreatePixCharge, asaasGetStatus };
