## 🚀 Configuração

### 1. Instalar dependências
```bash
npm install
```

### 2. Configurar token do bot
Edite `token.json`:
```json
{
  "token": "MTUyODE5ODc1MjU1OTQzNTc4Nw.G4W2-G.frz9ZTnoLWIZJNy_VvTODAutuZq1rskr80gTDA"
}
```

### 3. Configurar owner
Edite `Database/settings.json` e substitua `1178496286211719250` pelo seu ID do Discord.

### 4. Iniciar
```bash
npm start
# ou
node index.js
```

---

## 💳 Gateways de Pagamento

Configure todos pelo comando `/config > Configurações > Pagamentos`:

| Gateway | Tipo | API Automática |
|---|---|---|
| **Efí Bank** | PIX | ✅ Sim |
| **MercadoPago** | PIX | ✅ Sim |
| **Asaas** | PIX | ✅ Sim |
| **PagSeguro** | PIX | ✅ Sim |
| **Semi-Automático** | PIX | ❌ Manual |
| **Stripe** | Cartão/Link | ✅ Sim |
| **PicPay** | Link | ✅ Sim |
| **PayPal** | Link | ✅ Sim |

### Efí Bank
Requer certificado `.p12` na pasta `certs/`. Veja `certs/README.txt`.

### Asaas
Obtenha a API Key em: https://sandbox.asaas.com (sandbox) ou https://www.asaas.com (produção)

### PagSeguro
Token disponível no painel PagBank > API e Integrações.

### PicPay
Token em: https://lojista.picpay.com/configuracoes-da-conta

### PayPal
Credenciais em: https://developer.paypal.com/dashboard/

---

## ⭐ Auto-React

Configure em `/config > Auto-React`:
- Ative/desative o sistema
- Defina o emoji de reação (unicode ou emoji customizado do servidor)
- Selecione os canais onde o bot deve reagir automaticamente

---

## 📋 Painel de Feedbacks

Configure em `/config > Loja > Personalizações > Painel Feedbacks`:
- Ative o painel
- Defina URLs dos botões (Suporte, Estoque)
- O bot envia automaticamente o painel no canal de feedbacks configurado

---

## 📁 Estrutura
```
├── Comandos/         # Slash commands
├── Database/         # Banco de dados local (wio.db)
├── Eventos/          # Event handlers
│   ├── bot/          # Eventos do bot (ready)
│   ├── interaction/  # Handlers de interação
│   └── services/     # Serviços (auto-react, feedback, pedidos)
├── Functions/        # Funções auxiliares e gateways
│   ├── efi.js        # Efí Bank PIX
│   ├── pagamentos.js # Lógica principal de pagamentos
│   ├── picpay.js     # PicPay
│   ├── asaas.js      # Asaas
│   ├── pagseguro.js  # PagSeguro
│   ├── paypal.js     # PayPal
│   └── telas.js      # Painel /config (UI)
├── assets/           # Imagens (logo QR code)
├── certs/            # Certificados .p12 (Efí Bank)
└── index.js          # Entry point
```
