const { Client, GatewayIntentBits, Collection, Partials } = require("discord.js");
console.clear();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction]
});

module.exports = client;

client.slashCommands = new Collection();

const { token } = require("./token.json");

client.login(token);

const evento = require("./handler/Events");
evento.run(client);
require("./handler/index")(client);

client.setMaxListeners(30);

process.on('unhandledRejection', (reason, promise) => {
  console.log(`🚫 Erro Detectado:\n\n` + reason, promise);
});

process.on('uncaughtException', (error, origin) => {
  console.log(`🚫 Erro Detectado:\n\n` + error, origin);
});
