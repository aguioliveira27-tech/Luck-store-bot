Coloque aqui os certificados .p12 do Efí Bank:
- efi.p12 (certificado de produção ou homologação)

Para obter o certificado:
1. Acesse o painel da Efí Bank (gerencianet.com.br)
2. Vá em API > Chaves > Criar certificado
3. Faça o download do arquivo .p12
4. Renomeie para efi.p12 e coloque nesta pasta

Configure o caminho no /config > Configurações > Formas de Pagamento > Efí Bank
