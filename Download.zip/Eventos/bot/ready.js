const colors = require("colors");
const { Events } = require("discord.js");

module.exports = {
  name: Events?.ClientReady ?? "ready",
  run: async (client) => {
    console.log(colors.green("[STATUS]") + " " + client.user.username + " iniciado com sucesso.");
    console.log(colors.green("[STATUS]") + " Online em " + client.guilds.cache.size + " servidor(es).");
    console.log(colors.cyan("[INFO]") + " Bot de vendas carregado. Use /config para configurar.");
  }
};
