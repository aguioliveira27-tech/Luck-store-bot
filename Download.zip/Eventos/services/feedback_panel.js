const { ActionRowBuilder, ButtonBuilder } = require("discord.js");
const { General } = require("../../Database");

/**
 */

const isValidUrl = (u) => typeof u === "string" && /^https?:\/\//i.test(u);

module.exports = {
  name: "messageCreate",
  run: async (message, client) => {
    try {
      if (!message || message.author?.bot) return;

      const feedbackChannelId = General.get("Config.logs.feedbacks");
      if (!feedbackChannelId) return;
      if (message.channel?.id !== feedbackChannelId) return;

      // Só dispara quando alguém realmente mandou algo (texto ou imagem)
      const hasContent = typeof message.content === "string" && message.content.trim().length > 0;
      const hasAttach = message.attachments && message.attachments.size > 0;
      if (!hasContent && !hasAttach) return;

      const fp = General.get("System.Marca.feedbackPanel") || {};
      if (!fp.enabled) return;

      // Monta botões configuráveis
      const buttons = [];
      if (isValidUrl(fp.supportUrl)) {
        buttons.push(
          new ButtonBuilder()
            .setLabel("Suporte")
            .setStyle(5)
            .setURL(fp.supportUrl)
        );
      }
      if (isValidUrl(fp.stockUrl)) {
        buttons.push(
          new ButtonBuilder()
            .setLabel("Peça Estoque")
            .setStyle(5)
            .setURL(fp.stockUrl)
        );
      }

      const rows = buttons.length ? [new ActionRowBuilder().addComponents(buttons.slice(0, 5))] : [];

      const content = `#  Deixe seu Feedback!\n-# **Anexe uma imagem** com a **sua opinião** sobre nós! Para obter a __garantia do produto adquirido__. Seu **feedback** é muito importante! Isso nos ajuda a mostrar nosso trabalho ao novo público.`;

      // Apaga a última mensagem do painel (pra ficar sempre só 1 “fixa”)
      const lastMsgId = fp.lastMsgId;
      if (lastMsgId) {
        try {
          const old = await message.channel.messages.fetch(lastMsgId).catch(() => null);
          if (old) await old.delete().catch(() => null);
        } catch (_) {}
      }

      const sent = await message.channel.send({ content, components: rows }).catch(() => null);
      if (sent?.id) {
        await General.set("System.Marca.feedbackPanel.lastMsgId", sent.id);
      }
    } catch (_) {
      // não derruba o bot
    }
  }
};
