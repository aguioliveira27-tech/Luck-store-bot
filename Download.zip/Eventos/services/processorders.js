const { processOrder, approveOrder, hasPendingOrders, countPendingOrders } = require("../../Functions/carrinho");
const { ActivityType, Events } = require("discord.js");
const { General } = require("../../Database");

module.exports = {
  name: Events?.ClientReady ?? "ready",
  run: async (client) => {
    /**
     */

    // Scheduler otimizado: adapta a velocidade quando tem MUITOS carrinhos.
    // (pedido do OWNER: com muitos carrinhos, aprovação pode ir pra ~5/10s)
    const fastInterval = 1200; // padrão
    const midInterval = 5000;  // muitos carrinhos
    const heavyInterval = 10000; // carrinhos demais
    const slowInterval = 6000; // quando não há nada pendente
    let timer = null;

    const tick = async () => {
      try {
        await processOrder(client);
        await approveOrder(client);
      } catch (e) {
        console.log("⚠️ Erro no scheduler de pedidos:", e?.message || e);
      } finally {
        const pending = countPendingOrders ? countPendingOrders() : (hasPendingOrders() ? 1 : 0);
        let next = slowInterval;
        if (pending > 0 && pending < 15) next = fastInterval;
        else if (pending >= 15 && pending < 35) next = midInterval;
        else if (pending >= 35) next = heavyInterval;
        timer = setTimeout(tick, next);
      }
    };

    tick();
    // Status rotativo (seguro p/ v14/v15+ e sem .catch)
    let i = 0;
    setInterval(() => {
      let data = General.get("System.App.status");
      if (!data || !Array.isArray(data)) data = [];
      if (data.length === 0) return;

      // Suporta array de strings OU objetos { name, type, url }
      const item = data[i] ?? data[0];
      i = (i + 1) % data.length;

      let name = "";
      let url = undefined;
      let type = ActivityType.Playing;

      if (typeof item === "string") {
        name = item;
      } else if (item && typeof item === "object") {
        name = item.name ?? item.text ?? item.status ?? "";
        url = (typeof item.url === "string" && item.url.startsWith("http")) ? item.url : undefined;
        // se vier type numérico válido, usa; senão Playing
        if (typeof item.type === "number") type = item.type;
      }

      if (!name) return;

      try {
        client.user.setActivity(name, { type, url });
      } catch (e) {
        // não derruba o bot por status
      }
    }, 60000);

  }
};
