const { Events } = require("discord.js");
const { General } = require("../../Database");

/**
 * Sistema de Auto-React
 * Reage automaticamente a mensagens em canais configurados
 */
module.exports = {
  name: Events.MessageCreate ?? "messageCreate",
  run: async (message, client) => {
    try {
      if (!message || message.author?.bot) return;
      if (!message.guild) return;

      const cfg = General.get("System.AutoReact");
      if (!cfg || !cfg.enabled) return;

      const channels = cfg.channels;
      if (!Array.isArray(channels) || channels.length === 0) return;

      // Verifica se o canal atual está na lista de canais configurados
      if (!channels.includes(message.channel?.id)) return;

      const emoji = cfg.emoji;
      if (!emoji) return;

      // Suporte a emoji customizado (<:nome:ID>) e padrão (unicode)
      const customMatch = emoji.match(/^<a?:(\w+):(\d+)>$/);
      if (customMatch) {
        const emojiObj = message.guild.emojis.cache.get(customMatch[2]);
        if (emojiObj) {
          await message.react(emojiObj).catch(() => null);
        }
      } else {
        await message.react(emoji).catch(() => null);
      }
    } catch (_) {
      // Não derruba o bot
    }
  }
};
