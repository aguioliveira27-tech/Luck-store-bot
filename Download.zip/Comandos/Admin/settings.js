const { ApplicationCommandType, EmbedBuilder, MessageFlagsBitField } = require("discord.js");
const { General } = require("../../Database/index");
const { Main } = require("../../Functions/telas");
const startTime = Date.now();

module.exports = {
  name: "config",
  description: "[ADMIN] Gerenciar aplicação",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    const ownerId = General.get("owner");
    const adminRoleId = General.get("Config.Roles.admin");
    const isOwner = ownerId && interaction.user.id === ownerId;
    const isAdmin = adminRoleId ? interaction.member.roles.cache.has(adminRoleId) : false;

    if (!isOwner && !isAdmin) {
      return interaction.reply({
        content: "❌ Você não tem permissão para usar este comando.",
        flags: MessageFlagsBitField.Flags.Ephemeral
      });
    }

    const color = General.get("System.Colors.main") || "#a833ff";
    const ping = client.ws.ping;
    const uptime = `<t:${Math.ceil(startTime / 1000)}:R>`;

    const embed = new EmbedBuilder()
      .setAuthor({ name: `⚙️  Painel de Configuração`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setDescription(
        `Olá, **${interaction.user.username}** 👋\n\n` +
        `Bem-vindo ao painel central. Navegue pelas categorias abaixo para configurar cada aspecto da sua loja.\n\n` +
        `> 📡 **Ping:** \`${ping} ms\`  •  🕐 **Uptime:** ${uptime}`
      )
      .setColor(color)
      .setFooter({ text: `${interaction.guild.name}  •  ${client.user.username}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
      .setTimestamp();

    const { ActionRowBuilder, ButtonBuilder } = require("discord.js");

    await interaction.reply({
      content: "",
      embeds: [embed],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("GerenciarLoja").setLabel("Loja").setEmoji("1319043599521812480").setStyle(2),
          new ButtonBuilder().setCustomId("GerenciarTickets").setLabel("Atendimentos").setEmoji("1319043579179696271").setStyle(2),
          new ButtonBuilder().setCustomId("PersonalizaAPP").setLabel("Personalização").setEmoji("1319043534547976242").setStyle(2)
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("GerenciarDefinicoes").setLabel("Configurações").setEmoji("1319043594941759579").setStyle(2),
          new ButtonBuilder().setCustomId("autoReactSetup").setLabel("Auto-React").setEmoji("1319043602604752997").setStyle(2),
          new ButtonBuilder().setCustomId("rendimentosOptions").setLabel("Rendimentos").setEmoji("1319004166424891515").setStyle(2)
        )
      ],
      flags: MessageFlagsBitField.Flags.Ephemeral
    });
  }
};
